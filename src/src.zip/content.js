var RESET_ON_RELOAD = false;
var data = {
    currentTP:0,
    texturePacks: [],
    bc:"https://boxcritters.com/media/31-baseball/",
    from: {
        hamster:"critters/hamster.png",
        snail:"snail.png",
        items:"items.png",
        tavenProps:"rooms/HamTavern_SM.png"
    }
}

function save() {
    return new Promise((resolve,reject)=>{
        chrome.storage.sync.set({'bctpm':data},resolve);
    });
}

function load() {
    return new Promise((resolve,reject)=>{
        chrome.storage.sync.get(["bctpm"],(storage)=>{
            data = storage.bctpm || [];
            resolve(storage.bctpm);
        });
    });
}

function addDefault() {
    var tp = {};
    for (key in data.from) {
       tp[key] = data.bc + data.from[key]; // copies each property to the objCopy object
      }
    tp.name = "Box Critters";
    tp.version = 0;
    data.texturePacks.push(tp);
}

function reset() {
    chrome.storage.sync.set({"bctpm":undefined},()=>{});
    save();
}

//debugger;
if(RESET_ON_RELOAD){
    reset();
}
load();
if(data.texturePacks instanceof Array && data.texturePacks.length === 0
    //&&!data.texturePacks.map(tp=>tp.name).includes("Box Critters")
    ) {
    addDefault();
    save();
}

chrome.runtime.onMessage.addListener(({type,content},sender,sendResponse)=>{
    switch (type) {
        case "addtp": 
            data.texturePacks.push(content);
            save().then(()=>{
                sendResponse("Texture Pack successfuly added.");
            });
        break;
        case "gettexturepacks":
            sendResponse(data.texturePacks);
            break;
        case "getdata":
            sendResponse(data);
            break;
        case "refreshpage":
            chrome.tabs.reload();
            break;
        case "settp":
            data.currentTP = content.id;
            //sendResponse("Texture Pack successfuly set.");
            save().then(()=>{
                sendResponse("Texture Pack successfuly set.");
            });
            break;
        case "tpexists":
        sendResponse(data.texturePacks.map(tp=>tp.name).includes(content));
            break;
        default:
            sendResponse();
            break;
    }
});