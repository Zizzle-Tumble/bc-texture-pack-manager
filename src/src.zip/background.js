var rules = new Array();


function sendMessage(type,content,response) {
    console.log("Sending message:",{type,content});
    chrome.tabs.query({currentWindow:true,active:true},
        (tabs)=>{
            chrome.tabs.sendMessage(tabs[0].id,{type,content},response);
        }
    );
}

function load() {
    return new Promise((resolve,reject)=>{
        chrome.storage.sync.get(["bctpm"],(storage)=>{
            //data.texturePacks = storage.bctpm || [];
            /*var datadef = {
                currentTP:-1,
                texturePacks: [],
                bc:"https://boxcritters.com/media/",
                from: {}
            }*/
            resolve(storage.bctpm/*||datadef*/);
        });
    });
}




function saverules() {
    return new Promise((resolve,reject)=>{
        genrules().then((rules)=>{
            chrome.storage.sync.set({'bctpmRules':rules},resolve);
        })
    });
}

function loadrules() {
    return new Promise((resolve,reject)=>{
        chrome.storage.sync.get(["bctpmRules"],(storage)=>{
            rules = storage.bctpmRules || [];
            resolve(storage.bctpmRules);
        });
    });
}

function clone(obj) {
    if (null == obj || "object" != typeof obj) return obj;
    var copy = obj.constructor();
    for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
    }
    return copy;
}

function genrules() {
    return new Promise((resolve,reject)=>{
        load().then((data)=>{        
            if(data===undefined || data === {}){
                reject("no data was found");
                return;
            }
            
            //get current texture pack
            if(data.currentTP<0){
                reject("no texture pack was selected");
                return;
            }
            var currentTP = data.texturePacks[data.currentTP];
            console.log("current tp",data.currentTP);
            
            //Get Deafult texture pack
            var defaultTP = clone(data.from)
            var keys = Object.keys(defaultTP);
            keys.map(function(key) {
                defaultTP[key] = data.bc + defaultTP[key];
              });

            //get texture pack attributes
            keys = Object.keys(defaultTP);
            if(keys.length==0){
                resject("texture pack has no attributes");
                return;
            }

            rules = keys.reduce((result,key)=>{
                if(typeof result !== "object") {
                    result = {};
                }
                if(currentTP[key]&&currentTP[key] !== ""/*&&defaultTP[key] !== currentTP[key]*/){
                    result[key] = {from:defaultTP[key],to:currentTP[key]};
                }
                return result;
            });
            rules = Object.values(rules);
            //console.log("rules",rules);
            resolve(rules);
        }).catch(reject);
        //resolve([{from:"https://boxcritters.com/media/31-baseball/critters/hamster.png",to:"https://i.imgur.com/IXWBAYU.png"}])
    });
}

genrules().catch(console.error);
/*saverules().then(()=>{
    loadrules();
});
loadrules();*/

var lastRequestId;
function redirect(request) {
    
    /*if(request===undefined){
        return;
    }*/
    //genrules().then((rules)=>{
        //console.log("REQ_ID",request.requestId);
        //console.log("rules",rules);
        
        var rule = rules.find((rule)=>{
            return request.url == rule.from
            && request.requestId !== lastRequestId;
        });



        if(rule){
            console.log("rule",rule);
            console.log("Redirecting...");
            console.log(request.url.replace(rule.from, rule.to),"vs",rule.to);
            
            
            lastRequestId = request.requestId;
            return {
                //redirectUrl : request.url.replace(rule.from, rule.to)
                redirectUrl:rule.to
            };
        }
    //}).catch(console.error);
}

chrome.runtime.onMessage.addListener(({type,content}, sender, sendResponse)=> {
    switch (type) {
        case "refreshtp":
        
            genrules().then(()=>{
                sendResponse()
                console.log("pack set to",content);
            }).catch(sendResponse);
            break;
        default:
            break;
    }

    sendResponse();
});

chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
        return redirect(details);
    }, 
    {
        urls : ["https://boxcritters.com/media/*"]
    }, 
    ["blocking"]
);