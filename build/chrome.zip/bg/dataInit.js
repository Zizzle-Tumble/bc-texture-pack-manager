var browser = browser || chrome || msBrowser;
var RESET_ON_RELOAD = false;
var DATA = {
    currentTP: -1,
    editing: -1,
    texturePacks: []
}



function initDefaultTP() {

}

initDefaultTP();



const RESETDATA = DATA;