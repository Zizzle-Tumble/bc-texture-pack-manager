var RESET_ON_RELOAD = false;
var DATA = {
    currentTP: [],
    texturePacks: []
}


function initDefaultTP() {

}

initDefaultTP();



const RESETDATA = DATA;