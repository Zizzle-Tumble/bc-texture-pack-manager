var RESET_ON_RELOAD = false;
var DATA = {
    currentTP: [],
	texturePacks: [],
	currentShader:[],
	shaders:[]
}



const RESETDATA = DATA;